﻿import pandas as pd
import plotly.express as px
import streamlit as st
from pathlib import Path

# Paths
BASE_DIR = Path(__file__).parent
CSV_PATH = BASE_DIR / "2000_enriched.csv"

st.set_page_config(page_title="Transport Opinions - Austria", layout="wide")

@st.cache_data
def load_data(path: Path):
    df = pd.read_csv(path)
    if "time" in df.columns:
        df["time"] = pd.to_datetime(df["time"], errors="coerce")
        df["date"] = df["time"].dt.date
    return df

try:
    df = load_data(CSV_PATH)
except FileNotFoundError:
    st.error(f"CSV not found: {CSV_PATH}")
    st.stop()

st.title("Transport Opinions - Austria")
st.write("Interactive dashboard of emotions per station and over time.")

# Filters
col1, col2 = st.columns(2)
stations = sorted(df["station"].dropna().unique().tolist())
selected_stations = col1.multiselect("Stations", stations, default=stations[:5] if stations else [])
min_score, max_score = col2.slider("Emotion score range", 0.0, 1.0, (0.0, 1.0), 0.01)

if selected_stations:
    df_filtered = df[df["station"].isin(selected_stations)]
else:
    df_filtered = df.copy()

df_filtered = df_filtered[(df_filtered["emotion_score"] >= min_score) & (df_filtered["emotion_score"] <= max_score)]

# Quick stats
st.subheader("Quick stats")
c1, c2, c3 = st.columns(3)
c1.metric("Rows", len(df_filtered))
c2.metric("Stations", df_filtered["station"].nunique())
top_emotion = df_filtered["emotion"].mode().iloc[0] if not df_filtered.empty else "-"
c3.metric("Top emotion", top_emotion)

# Emotion distribution
st.subheader("Emotion distribution")
if df_filtered.empty:
    st.info("No data after filters.")
else:
    emo_counts = df_filtered["emotion"].value_counts().reset_index()
    emo_counts.columns = ["emotion", "count"]
    fig_emo = px.bar(emo_counts, x="emotion", y="count", color="emotion", title="Counts by emotion")
    st.plotly_chart(fig_emo, use_container_width=True)

# Top stations by dominant emotion
st.subheader("Top stations by dominant emotion")
if df_filtered.empty:
    st.info("No data to show.")
else:
    station_dom = (
        df_filtered.groupby("station")["emotion"]
        .agg(lambda s: s.value_counts().idxmax())
        .reset_index(name="dominant_emotion")
    )
    station_counts = df_filtered.groupby("station").size().reset_index(name="n")
    station_summary = station_dom.merge(station_counts, on="station")
    fig_station = px.treemap(
        station_summary,
        path=["dominant_emotion", "station"],
        values="n",
        color="dominant_emotion",
        title="Stations grouped by dominant emotion (size = #opinions)",
    )
    st.plotly_chart(fig_station, use_container_width=True)

# Emotion over time
if "date" in df_filtered.columns:
    st.subheader("Emotion over time")
    if df_filtered.empty:
        st.info("No data to show.")
    else:
        time_series = (
            df_filtered.groupby(["date", "emotion"]).size()
            .reset_index(name="count")
            .sort_values("date")
        )
        fig_time = px.line(time_series, x="date", y="count", color="emotion", markers=True,
                           title="Counts by emotion over time")
        st.plotly_chart(fig_time, use_container_width=True)

st.subheader("Sample data")
st.dataframe(df_filtered[["time", "station", "text", "emotion", "emotion_score"]].head(300), use_container_width=True)
