"""
Pipeline to process public transport opinions (Austria) with Pandas + Transformers.

Input CSV (UTF-8): 2000.csv with columns: time, station, text
Outputs:
 - 2000_enriched.csv : original data + predicted emotion + score
 - station_summary.csv: aggregated metrics per station
 - time_summary.csv: aggregated metrics by date (YYYY-MM-DD)

Model: emotion classifier from Hugging Face (DistilRoBERTa fine-tuned on emotions).
"""

import re
from collections import Counter, namedtuple
from pathlib import Path
from typing import Iterable, List

import pandas as pd
from transformers import pipeline


# --- Paths ---
BASE_DIR = Path(__file__).parent
INPUT_CSV = BASE_DIR / "2000.csv"
OUTPUT_CSV = BASE_DIR / "2000_enriched.csv"
STATION_SUMMARY_CSV = BASE_DIR / "station_summary.csv"
TIME_SUMMARY_CSV = BASE_DIR / "time_summary.csv"


# --- Config ---
BATCH_SIZE = 32
TEXT_COLUMN = "text"
STATION_COLUMN = "station"
TIME_COLUMN = "time"
# Emotion model (English)
EMOTION_MODEL = "j-hartmann/emotion-english-distilroberta-base"


EmotionResult = namedtuple("EmotionResult", ["label", "score"])


def load_data(path: Path = INPUT_CSV) -> pd.DataFrame:
    """Load CSV with required columns."""
    df = pd.read_csv(path)
    expected = {TIME_COLUMN, STATION_COLUMN, TEXT_COLUMN}
    missing = expected - set(df.columns)
    if missing:
        raise ValueError(f"Missing columns in CSV: {missing}")
    return df


def clean_text(text: str) -> str:
    """Light cleaning: lower, strip, collapse whitespace."""
    if not isinstance(text, str):
        return ""
    text = text.strip()
    text = re.sub(r"\s+", " ", text)
    return text


def preprocess(df: pd.DataFrame) -> pd.DataFrame:
    """Clean text and drop empty rows."""
    df = df.copy()
    df[TEXT_COLUMN] = df[TEXT_COLUMN].apply(clean_text)
    df = df[df[TEXT_COLUMN].str.len() > 0]
    # Normalize station names to title case and trim whitespace
    df[STATION_COLUMN] = df[STATION_COLUMN].astype(str).str.strip()
    return df


def batched(iterable: Iterable[str], batch_size: int) -> Iterable[List[str]]:
    """Yield lists of size batch_size from iterable."""
    batch: List[str] = []
    for item in iterable:
        batch.append(item)
        if len(batch) == batch_size:
            yield batch
            batch = []
    if batch:
        yield batch


def classify_emotions(texts: List[str], clf) -> List[EmotionResult]:
    """
    Run the HF pipeline in batch mode, returning top label and score per text.
    Assumes clf is a pipeline("text-classification", return_all_scores=False) or similar.
    """
    outputs = clf(texts)
    results = []
    for out in outputs:
        # Some pipelines return dict, others list; normalize
        if isinstance(out, list) and out and isinstance(out[0], dict):
            # If return_all_scores=True was used, pick max
            best = max(out, key=lambda d: d.get("score", 0.0))
        elif isinstance(out, dict):
            best = out
        else:
            raise ValueError(f"Unexpected pipeline output: {out}")
        results.append(EmotionResult(label=best["label"], score=float(best["score"])))
    return results


def run_emotion_inference(df: pd.DataFrame) -> pd.DataFrame:
    """Annotate DataFrame with emotion predictions."""
    clf = pipeline(
        task="text-classification",
        model=EMOTION_MODEL,
        top_k=None,  # return top label unless return_all_scores is True
        truncation=True,
    )
    labels = []
    scores = []
    for batch in batched(df[TEXT_COLUMN].tolist(), BATCH_SIZE):
        preds = classify_emotions(batch, clf)
        labels.extend([p.label for p in preds])
        scores.extend([p.score for p in preds])
    df_out = df.copy()
    df_out["emotion"] = labels
    df_out["emotion_score"] = scores
    return df_out


def summarize_by_station(df: pd.DataFrame) -> pd.DataFrame:
    """Aggregate counts and top emotion per station."""
    grp = df.groupby(STATION_COLUMN)
    agg = grp.agg(
        n=("emotion", "count"),
        dominant_emotion=("emotion", lambda s: Counter(s).most_common(1)[0][0] if len(s) else None),
        avg_emotion_score=("emotion_score", "mean"),
    ).reset_index()
    return agg.sort_values("n", ascending=False)


def summarize_by_date(df: pd.DataFrame) -> pd.DataFrame:
    """Aggregate counts/emotion by date (YYYY-MM-DD)."""
    df = df.copy()
    df["date"] = pd.to_datetime(df[TIME_COLUMN]).dt.date
    grp = df.groupby("date")
    agg = grp.agg(
        n=("emotion", "count"),
        dominant_emotion=("emotion", lambda s: Counter(s).most_common(1)[0][0] if len(s) else None),
        avg_emotion_score=("emotion_score", "mean"),
    ).reset_index()
    return agg.sort_values("date")


def main():
    df_raw = load_data(INPUT_CSV)
    df = preprocess(df_raw)
    df_emotions = run_emotion_inference(df)

    # Save enriched data
    df_emotions.to_csv(OUTPUT_CSV, index=False)

    # Summaries
    station_summary = summarize_by_station(df_emotions)
    station_summary.to_csv(STATION_SUMMARY_CSV, index=False)

    time_summary = summarize_by_date(df_emotions)
    time_summary.to_csv(TIME_SUMMARY_CSV, index=False)

    print(f"Processed {len(df_emotions)} rows.")
    print(f"Enriched data -> {OUTPUT_CSV}")
    print(f"Station summary -> {STATION_SUMMARY_CSV}")
    print(f"Time summary -> {TIME_SUMMARY_CSV}")


if __name__ == "__main__":
    main()
