"""
Visualización básica de:
- station_summary.csv
- time_summary.csv

Requisitos:
    pip install pandas matplotlib
"""

import pandas as pd
import matplotlib.pyplot as plt

# ------------------------------------
# 1. Cargar datos
# ------------------------------------
# Ajusta las rutas si es necesario
STATION_FILE = "station_summary.csv"
TIME_FILE = "time_summary.csv"

station_df = pd.read_csv(STATION_FILE)
time_df = pd.read_csv(TIME_FILE)

# ------------------------------------
# 2. Añadir emojis a las emociones
# ------------------------------------
emotion_to_emoji = {
    "joy": "😄",
    "anger": "😡",
    "sadness": "😢",
    "fear": "😨",
    "disgust": "🤢",
    "surprise": "😮",
    "neutral": "😐",
}

# Columna extra con el emoji correspondiente
station_df["emotion_emoji"] = station_df["dominant_emotion"].map(emotion_to_emoji).fillna("❓")
time_df["emotion_emoji"] = time_df["dominant_emotion"].map(emotion_to_emoji).fillna("❓")

# ------------------------------------
# 3. Vista rápida en consola (opcional)
# ------------------------------------
print("\n=== Station summary (with emojis) ===")
print(station_df.head(20))

print("\n=== Time summary (with emojis) ===")
print(time_df.head())

# ------------------------------------
# 4. Gráfica: número de opiniones por estación
# ------------------------------------
# Ordenamos por número de respuestas
station_sorted = station_df.sort_values("n", ascending=True)

plt.figure(figsize=(10, 6))
plt.barh(station_sorted["station"], station_sorted["n"])
plt.xlabel("Number of responses")
plt.ylabel("Station")
plt.title("Number of responses per station")

# Opcional: añadimos el emoji al final de cada barra
for i, (value, emoji) in enumerate(zip(station_sorted["n"], station_sorted["emotion_emoji"])):
    plt.text(value + 5, i, emoji, va="center")  # 5 = pequeño offset horizontal

plt.tight_layout()
plt.show()

# ------------------------------------
# 5. Gráficas en el tiempo
# ------------------------------------
# Aseguramos que 'date' es tipo fecha
time_df["date"] = pd.to_datetime(time_df["date"])

# Orden por fecha
time_df = time_df.sort_values("date")

# Figura 1: número de respuestas por día
plt.figure(figsize=(10, 4))
plt.plot(time_df["date"], time_df["n"], marker="o")
plt.xlabel("Date")
plt.ylabel("Number of responses")
plt.title("Number of responses over time")
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.show()

# Figura 2: score medio de emoción por día
plt.figure(figsize=(10, 4))
plt.plot(time_df["date"], time_df["avg_emotion_score"], marker="o")
plt.xlabel("Date")
plt.ylabel("Average emotion score")
plt.title("Average emotion score over time")
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.show()

# ------------------------------------
# 6. (Opcional) Tabla resumen global
# ------------------------------------
# Ejemplo de “top estaciones problemáticas” según emoción y score
print("\n=== Stations with highest anger score (example filter) ===")
angry_stations = station_df[station_df["dominant_emotion"] == "anger"].sort_values(
    "avg_emotion_score", ascending=False
)
print(angry_stations.head(10))
